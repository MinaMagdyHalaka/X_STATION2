<?php

return [
    'resignation' => 'Démission',
    'termination' => 'Licenciement',
    'retirement' => 'Retraite',
    'pending' => 'Pending',
    'accepted' => 'Accepted',
    'rejected' => 'Rejected',
];

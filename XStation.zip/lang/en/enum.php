<?php

return [
    'resignation' => 'Resignation',
    'termination' => 'Termination',
    'retirement' => 'Retirement',
    'pending' => 'Pending',
    'accepted' => 'Accepted',
    'rejected' => 'Rejected',
];

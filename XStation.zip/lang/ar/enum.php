<?php

return [

    'resignation' => 'استقالة',
    'termination' => 'اقاله',
    'retirement' => 'تقاعد',
    'pending' => 'انتظار',
    'accepted' => 'تم قبوله',
    'rejected' => 'تم رفضه',
];

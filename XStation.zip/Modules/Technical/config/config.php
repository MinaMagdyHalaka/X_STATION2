<?php

return [
    'name' => 'Technical',
];

<?php

return [
    'name' => 'Post',
];
